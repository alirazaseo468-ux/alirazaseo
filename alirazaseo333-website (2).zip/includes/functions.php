<?php
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }

function data_file() { return __DIR__ . '/../data/articles.json'; }

function get_articles() {
    $file = data_file();
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function save_articles($articles) {
    file_put_contents(data_file(), json_encode($articles, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function slugify($text) {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-') ?: 'article';
}

function create_article($post) {
    $title = trim($post['title'] ?? '');
    $author = trim($post['author'] ?? '');
    $category = trim($post['category'] ?? 'SEO');
    $url = trim($post['url'] ?? '');
    $content = trim($post['content'] ?? '');

    if ($title === '' || $author === '' || $content === '') return ['ok'=>false, 'error'=>'Please fill in the title, name and article content.'];
    if ($url !== '' && !filter_var($url, FILTER_VALIDATE_URL)) return ['ok'=>false, 'error'=>'Please enter a valid website URL.'];
    if (strlen($title) > 180 || strlen($author) > 80) return ['ok'=>false, 'error'=>'Title or author name is too long.'];

    $articles = get_articles();
    $slug = slugify($title);
    $base = $slug; $n = 2;
    while (find_article($slug, $articles)) { $slug = $base . '-' . $n++; }

    $article = [
        'slug'=>$slug, 'title'=>$title, 'author'=>$author,
        'category'=>$category ?: 'SEO', 'url'=>$url,
        'content'=>$content, 'date'=>date('Y-m-d')
    ];
    array_unshift($articles, $article);
    save_articles($articles);
    return ['ok'=>true, 'slug'=>$slug];
}

function find_article($slug, $articles=null) {
    $articles = $articles ?? get_articles();
    foreach ($articles as $a) if (($a['slug'] ?? '') === $slug) return $a;
    return null;
}

function sanitize_content($html) {
    // Remove dangerous tags/attributes while keeping basic article formatting and links.
    $html = preg_replace('/<\s*(script|style|iframe|object|embed|form|input|button)[^>]*>.*?<\s*\/\s*\1\s*>/is', '', $html);
    $html = preg_replace('/\s+on[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+)/is', '', $html);
    $html = preg_replace('/javascript\s*:/i', '', $html);
    $allowed = '<p><br><strong><b><em><i><u><h2><h3><h4><ul><ol><li><blockquote><a>';
    return strip_tags($html, $allowed);
}

function article_excerpt($html, $length=180) {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
    return strlen($text) > $length ? substr($text, 0, $length) . '…' : $text;
}